#!/usr/bin/env python3
"""
Backend API for Dr. Robert Young's semantic search Q&A system

This module provides a FastAPI application that:
1. Performs semantic search on scraped blog articles
2. Generates contextual answers using local LLM
3. Provides performance timing information
"""

# Standard library imports
import sys
import os
import time
import re
import ast
import subprocess
import numpy as np
from collections import deque

# Third-party imports
from fastapi import FastAPI
from pydantic import BaseModel
import requests
from sentence_transformers import SentenceTransformer

# Local imports
# Add the project root directory to the Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.insert(0, project_root)
from database.db import get_connection

# Initialize FastAPI app
app = FastAPI(
    title="Dr. Robert Young Semantic Search API",
    description="Semantic search and Q&A system for Dr. Robert Young's blog content",
    version="1.0.0"
)

# Initialize embedding model for vector search
# Using all-MiniLM-L6-v2 for efficient sentence embeddings
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# Session-based conversation memory (stores last 5 interactions per conversation)
conversation_memory = {}

def get_conversation_history(conversation_id: str):
    """Get conversation history for given ID"""
    if conversation_id not in conversation_memory:
        conversation_memory[conversation_id] = deque(maxlen=5)
    return conversation_memory[conversation_id]

def add_to_conversation_history(conversation_id: str, question: str, answer: str):
    """Add interaction to conversation history"""
    history = get_conversation_history(conversation_id)
    history.append({
        "question": question,
        "answer": answer,
        "timestamp": time.time()
    })
    
    # Log the addition
    print(f"💾 SAVED TO SESSION [{conversation_id}]:")
    print(f"   Question: {question[:60]}...")
    print(f"   Answer: {answer[:60]}...")
    print(f"   Total interactions: {len(history)}")


class ChatRequest(BaseModel):
    """
    Request model for chat endpoint
    
    Attributes:
        question (str): The user's question to be answered
        conversation_id (str): Optional conversation identifier to maintain context
    """
    question: str
    conversation_id: str = "default"


def cosine(a, b):
    """
    Calculate cosine similarity between two vectors
    
    Args:
        a (numpy.ndarray): First vector
        b (numpy.ndarray): Second vector
        
    Returns:
        float: Cosine similarity score between 0 and 1
    """
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))


def clean_context(text: str) -> str:
    """
    Clean and preprocess context text for LLM consumption
    
    This function removes unwanted formatting elements that might confuse the LLM.
    
    Args:
        text (str): Raw text content to be cleaned
        
    Returns:
        str: Cleaned text ready for LLM processing
    """
    # Remove numbered points like "1.", "2)"
    text = re.sub(r"\n?\s*\d+[\.]\)\s*", " ", text)

    # Remove bullet symbols
    text = re.sub(r"[•\-–▪]", " ", text)

    # Remove reference / links section
    stop_words = ["References", "REFERENCES", "http", "www."]
    for w in stop_words:
        if w in text:
            text = text.split(w)[0]

    return text.strip()


# List of terms to avoid in responses to maintain neutrality
FORBIDDEN_TERMS = [
    "ph.d", "m.sc", "d.sc", "naturopath",
    "disseminated", "coagulation", "dic",
    "pathology", "mechanism", "theoretical",
    "robert", "young"
]


def sanitize_answer(text: str, question: str) -> str:
    """
    Sanitize answer based on question type
    
    This function applies specific response patterns for certain types of questions
    to ensure scientifically accurate and appropriately cautious responses.
    
    Args:
        text (str): Original answer text from LLM
        question (str): Original user question
        
    Returns:
        str: Potentially modified answer based on question type
    """
    q = question.lower()

    # Case 1: Handle questions about study size or proof
    if any(k in q for k in ["small", "three", "prove", "study"]):
        return (
            "Based on the information provided in the blog context, the study is exploratory "
            "and limited by its very small sample size. It cannot establish proof that the "
            "intervention removes toxins from the human body. The findings provide only initial "
            "observations, and larger, well-controlled studies would be required to draw "
            "definitive conclusions."
        )

    # Case 2: Handle questions about product differences or comparisons
    if any(k in q for k in ["different", "compare", "market", "other"]):
        return (
            "The blog context does not explicitly provide information about the study size, "
            "its stated purpose, or its methodological limitations in relation to this question. "
            "As a result, no conclusions can be drawn based on the available information. "
            "Further well-controlled studies would be required to address this topic."
        )

    return text


def call_llama2(prompt: str) -> str:
    """
    Call locally running LLM via Ollama
    
    Args:
        prompt (str): The formatted prompt to send to the LLM
        
    Returns:
        str: Generated response from the LLM or error message
    """
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "llama2:latest",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.7,      # Control randomness
                    "top_p": 0.9,           # Nucleus sampling
                    "repeat_penalty": 1.2,  # Reduce repetition
                    "num_predict": 100      # Limit response length
                }
            },
            timeout=180  # 3-minute timeout
        )

        # 🔍 DEBUG: raw response
        print("OLLAMA STATUS:", response.status_code)
        print("OLLAMA RAW:", response.text)

        data = response.json()

        # ✅ SAFETY CHECKS
        if not isinstance(data, dict):
            return "Invalid response format from LLaMA-2."

        answer = data.get("response", "").strip()

        if not answer:
            return (
                "Based on the provided context, the available information is limited. "
                "The article discusses the topic in a general or theoretical manner "
                "and does not provide sufficient evidence to give a detailed answer."
            )

        return answer

    except Exception as e:
        return f"LLaMA-2 API error: {str(e)}"

@app.post("/chat")
async def chat(q: ChatRequest):
    """
    Main chat endpoint that processes user questions with session-based memory
    
    This endpoint performs semantic search on the blog database, maintains conversation
    context, and generates contextual answers using a local LLM.
    
    Args:
        q (ChatRequest): The user's question request with optional conversation ID
        
    Returns:
        dict: Response containing answer, references, and timing breakdown
    """
    # Start timing for performance measurement
    start_time = time.time()
    
    # Get conversation history
    history = get_conversation_history(q.conversation_id)
    
    # Log conversation tracking
    print(f"🔄 CONVERSATION SESSION: {q.conversation_id}")
    print(f"📊 HISTORY LENGTH: {len(history)} interactions")
    
    # Build context from conversation history
    history_context = ""
    if history:
        history_lines = []
        for item in history:
            history_lines.append(f"Previous question: {item['question']}")
            history_lines.append(f"Previous answer: {item['answer']}")
        history_context = "\n".join(history_lines) + "\n"
        print(f"📝 CONTEXT LINES ADDED: {len(history_lines)}")

    # 1️⃣ Embed user question using sentence transformer
    embed_start = time.time()
    query_emb = embed_model.encode(q.question)
    embed_time = time.time() - embed_start

    # 2️⃣ Fetch articles from database
    db_start = time.time()
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT title, content, embedding FROM dr_young_all_articles LIMIT 50")
    rows = cur.fetchall()
    db_time = time.time() - db_start

    # Prepare list to store similarity scores
    scored = []

    # 3️⃣ Perform vector similarity search
    search_start = time.time()
    for r in rows:
        # Convert stored embedding string back to numpy array
        emb = np.array(ast.literal_eval(r["embedding"]))
        # Calculate cosine similarity with query
        score = cosine(query_emb, emb)

        # Boost score if query terms appear in title
        if any(word in r["title"].lower() for word in q.question.lower().split()):
            score += 0.1

        # Only consider results above threshold
        if score > 0.30:
            scored.append((score, r))

    # Sort by similarity score and take top result
    scored = sorted(scored, key=lambda x: x[0], reverse=True)[:1]
    search_time = time.time() - search_start

    # Return if no relevant results found
    if not scored:
        return {
            "answer": "No relevant information found in the available blogs.",
            "references": []
        }

    # 4️⃣ Build context from top matching articles
    context_start = time.time()
    context_parts = []
    references = []  # Track source references

    for _, art in scored:
        # Add article title to references
        references.append(art["title"])
        # Clean and truncate article content
        cleaned = clean_context(art["content"][:200])
        context_parts.append(cleaned)

    print("CONTEXT LENGTH:", len(context_parts))

    # Join all context parts
    context = "\n\n".join(context_parts)
    context_time = time.time() - context_start

    # 5️⃣ Format prompt for LLM with conversation context
    prompt = f"""
{history_context}Context: {context}

Question: {q.question}

Answer (1-2 sentences max):"""
    
    # 6️⃣ Generate answer using local LLM
    llm_start = time.time()
    answer = call_llama2(prompt)
    llm_time = time.time() - llm_start
    # Clean up extra whitespace in answer
    answer = " ".join(answer.split())
    
    # Add this interaction to conversation history
    add_to_conversation_history(q.conversation_id, q.question, answer)
    
    # Calculate total processing time
    total_time = time.time() - start_time
    
    # Print detailed timing breakdown
    print(f"⏱️ TIMING BREAKDOWN:")
    print(f"   Embedding: {embed_time:.2f}s")
    print(f"   Database: {db_time:.2f}s")
    print(f"   Search: {search_time:.2f}s")
    print(f"   Context building: {context_time:.2f}s")
    print(f"   LLM generation: {llm_time:.2f}s")
    print(f"   TOTAL: {total_time:.2f}s")
    
    return {
        "answer": answer,
        "references": references,
        "timing": {
            "embedding": round(embed_time, 2),
            "database": round(db_time, 2),
            "search": round(search_time, 2),
            "context_building": round(context_time, 2),
            "llm_generation": round(llm_time, 2),
            "total": round(total_time, 2)
        }
    }
